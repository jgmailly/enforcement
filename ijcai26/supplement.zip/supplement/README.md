Supplement for IJCAI 2026 submission "A Versatile Framework for Formula-Based Enforcement and Synthesis in Abstract Argumentation"
==================================================================================================================================

Contents
--------
- `proofs.pdf`: Full proofs of formal results presented in the paper.
- `benchmarks/*`: Benchmark generators and instances (AFs and enforcement queries) used in the evaluation.
- `code/*'`: Implementation of the MaxSAT-based CEGAR algorithm for formula-based enforcement.
- `results/*`: Logs and CSV files with full empirical results.

Dependencies
------------

The code requires the PySAT library to run. PySAT is installed by issuing the following command.

```
pip3 install python-sat
```

Evaluation
----------

The empirical evaluation was run on Intel(R) Xeon(R) Gold 6248 CPUs @ 2.50GHz with a 600-second time limit and 32-GB memory limit.
The OS was AlmaLinux 8.4 (Electric Cheetah) with kernel 4.18.0-372.9.1.el8.x86_64. We used Python 3.13.5 compiled with GCC 14.3.0.

To run the empirical evaluation, download [the runsolver tool](https://www.cril.univ-artois.fr/~roussel/runsolver/), and issue the following commands `for file in ./benchmarks/*.apx`:
```
./runsolver --timestamp -d 15 -o $file.cred-stb.out -v $file.cred-stb.var -w $file.cred-stb.wat -C 600 -M 32768 ./code/formula_enforcement.py --semantics=stb --mode=cred --semantic-targets --pos-conjunct-weight=1 --neg-conjunct-weight=1 $file $file.query
./runsolver --timestamp -d 15 -o $file.cred-adm.out -v $file.cred-adm.var -w $file.cred-adm.wat -C 600 -M 32768 ./code/formula_enforcement.py --semantics=adm --mode=cred --semantic-targets --pos-conjunct-weight=1 --neg-conjunct-weight=1 $file $file.query
```

Usage
-----

```
usage: formula_enforcement.py [-h] [--semantics {adm,stb}] [--mode {cred,skept}] [--verbose] [--pos-cred-weight POS_CRED_WEIGHT] [--neg-cred-weight NEG_CRED_WEIGHT] [--pos-skept-weight POS_SKEPT_WEIGHT]
                              [--neg-skept-weight NEG_SKEPT_WEIGHT] [--pos-conjunct-weight POS_CONJUNCT_WEIGHT] [--neg-conjunct-weight NEG_CONJUNCT_WEIGHT] [--semantic-targets] [--lex]
                              af query [cons]

Formula-Based Enforcement Solver

positional arguments:
  af                    Input filename for AF instance.
  query                 Input filename for enforcement query. Currently supports target(), neg_target(), pos_conjunct(), and neg_conjunct() predicates.
  cons                  Input filename for constraints on the attack structure. Currently supports att() and -att() predicates.

options:
  -h, --help            show this help message and exit
  --semantics {adm,stb}
                        Argumentation semantics (adm or stb).
  --mode {cred,skept}   Reasoning mode (cred or skept).
  --verbose             Verbose output.
  --pos-cred-weight POS_CRED_WEIGHT
                        Weight for positive credulous targets (default: inf).
  --neg-cred-weight NEG_CRED_WEIGHT
                        Weight for negative credulous targets (default: inf).
  --pos-skept-weight POS_SKEPT_WEIGHT
                        Weight for positive skeptical targets (default: inf).
  --neg-skept-weight NEG_SKEPT_WEIGHT
                        Weight for negative skeptical targets (default: inf).
  --pos-conjunct-weight POS_CONJUNCT_WEIGHT
                        Weight for positive conjunctive targets (default: inf).
  --neg-conjunct-weight NEG_CONJUNCT_WEIGHT
                        Weight for negative conjunctive targets (default: inf).
  --semantic-targets    Modify targets to take accepted arguments into account.
  --lex                 Employ lexicographic instead of weight-based optimization.
```
