import random
import math

def generate_apx(n, p, q):
	apx_result = ""
	for i in range(1,n+1):
		apx_result += f"arg(a{i}).\n"

	for i in range(1,n+1):
		for j in range(i+1, n+1):
			if random.random() < p:
				if random.random() < q:
					apx_result += f"att(a{i},a{j}).\n"
					apx_result += f"att(a{j},a{i}).\n"
				else:
					if random.random() < 0.5:
						apx_result += f"att(a{i},a{j}).\n"
					else:
						apx_result += f"att(a{j},a{i}).\n"
	return apx_result

seed = 2025
random.seed(seed)

for n_args in range(20, 201, 10):
	for p in [0.025, 0.05, 0.1, 0.2, 0.4]:
		q = (2.0 - 2.0*math.sqrt(1.0 - p) - p)/p
		#print(p, q)
		for i in range(0,10):
			apx = generate_apx(n_args, p, q)
			with open("af_" + str(n_args) + "_" + str(round(p*1000)) + "_" + str(i) + ".apx", "w") as file:
				file.write(apx)
