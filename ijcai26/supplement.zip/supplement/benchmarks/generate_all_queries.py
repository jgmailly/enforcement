import random
import math
import os

seed = 2025
random.seed(seed)

files = [file.replace(".apx", "") for file in os.listdir(".") if file.endswith(".apx")]

for file in sorted(files, key=lambda s: (int(s.split("_")[1]), int(s.split("_")[2]), int(s.split("_")[3]))):
	contents = [line for line in open(file + ".apx").read().split("\n") if len(line) > 0]
	args = [line.replace("arg(", "").replace(").", "") for line in contents if line.startswith("arg")]
	pos_enfs = sorted(random.sample(args, int(len(args)/10)), key=lambda s: int(s[1:]))
	remaining = sorted(list(set(args).difference(set(pos_enfs))), key=lambda s: int(s[1:]))
	neg_enfs = sorted(random.sample(remaining, int(len(args)/10)), key=lambda s: int(s[1:]))
	neg_remaining = sorted(list(set(args).difference(set(neg_enfs))), key=lambda s: int(s[1:]))
	pos_conjuncts = []
	for _ in range(0,5):
		pos_enf = sorted(random.sample(neg_remaining, int(len(pos_enfs))))
		pos_conjuncts += [pos_enf]
	neg_conjuncts = []
	for _ in range(0,5):
		neg_enf = sorted(random.sample(neg_remaining, int(len(pos_enfs))))
		neg_conjuncts += [neg_enf]
	with open(file + ".apx" + ".query", "w") as query_file:
		query_file.write("target(" + ",".join(pos_enfs) + ")." + "\n")
		query_file.write("neg_target(" + ",".join(neg_enfs) + ")." + "\n")
		for pos_enf in pos_conjuncts:
			query_file.write("pos_conjunct(" + ",".join(pos_enf) + ")." + "\n")
		for neg_enf in neg_conjuncts:
			query_file.write("neg_conjunct(" + ",".join(neg_enf) + ")." + "\n")